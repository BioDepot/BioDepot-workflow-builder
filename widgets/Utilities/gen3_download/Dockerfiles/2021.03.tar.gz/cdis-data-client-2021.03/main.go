package main

import (
	"github.com/uc-cdis/gen3-client/gen3-client/g3cmd"
)

func main() {
	g3cmd.Execute()
}
