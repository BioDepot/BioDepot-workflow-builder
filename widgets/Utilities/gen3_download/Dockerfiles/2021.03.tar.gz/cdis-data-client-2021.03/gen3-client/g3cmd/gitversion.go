package g3cmd

const (
	gitcommit  = "N/A"
	gitversion = "N/A"
)
